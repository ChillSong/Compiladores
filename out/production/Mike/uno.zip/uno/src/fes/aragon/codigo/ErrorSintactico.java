package fes.aragon.codigo;

public class ErrorSintactico extends RuntimeException {
    public ErrorSintactico(String message) {
        super(message);
    }
}
